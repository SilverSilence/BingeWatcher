#BingeWatcher
The idea is to automatically load the next episode and increase video size. The version is still very basic and thus could be improved in terms of features and optimization.

##How to use
By right-clicking a selected text, one can store a new show-entry. It is stored along with the current URL which is seen as the "last unseen episode". The next step is to right-click the "next episode button/link". This updates the entry with the DOM-Path to that link.

By clicking the plugin icon, a popup appears, showing a list of the saved titles as links. That's also the place where a user can delete his entries.
